import discord
from discord.ext import commands
import music

cogs = [music]

client = commands.Bot(command_prefix = '?', intents = discord.Intents.all())

for i in range(len(cogs)):
	cogs[i].setup(client)


@client.event
async def on_ready():
	print('bot ready.')

client.run('ODkwNjQwMTg2MzY5Nzk0MDU4.YUyvTw.ockYTghmPJ2sxiLvQM77n0EMwFw')
